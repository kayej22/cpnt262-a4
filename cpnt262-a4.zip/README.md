# CPTN 262-a4
Joel Kaye

## Github Repository
  https://github.com/kayej22/cpnt262-a4

## Heroku Link
   https://kayecpnt262-a4.herokuapp.com/


## General Notes
  Tried to get the Dayjs module to function properly but just got stuck trying to make the module work. I can make the function string appear in the registry page but when I try to connect the module using require in the server it breaks my entire connection.


## attributions

### images

  Leeroy
  Photo by <a href="https://cdn.stocksnap.io/img-thumbs/960w/snow-snowing_M1G6NWULHL.jpg">Leeroy</a> from <a href="https://stocksnap.io">StockSnap</a>
  https://stocksnap.io/license

  Leeroy
  Photo by <a href="https://cdn.stocksnap.io/img-thumbs/960w/ice-snow_QFVTG5T37V.jpg">Charles Forerunner</a> from <a href="https://stocksnap.io">StockSnap</a>
  https://stocksnap.io/license

  Leeroy
  Photo by <a href="https://cdn.stocksnap.io/img-thumbs/960w/buildings-architecture_5CXNO08OHT.jpg">One Idea LLC</a> from <a href="https://stocksnap.io">StockSnap</a>
  https://stocksnap.io/license

  Leeroy
  https://cdn.stocksnap.io/img-thumbs/960w/guy-man_DM8MFOGVFG.jpg
  https://stocksnap.io/license

  Leeroy
  https://cdn.stocksnap.io/img-thumbs/960w/guy-man_DM8MFOGVFG.jpg
  https://stocksnap.io/license

  Leeroy
  https://cdn.stocksnap.io/img-thumbs/960w/taxi-boat_T56JW384MI.jpg
  https://stocksnap.io/license

  Leeroy
  https://cdn.stocksnap.io/img-thumbs/960w/guy-man_Q42LWDSRWX.jpg
  https://stocksnap.io/license

  Leeroy
  https://cdn.stocksnap.io/img-thumbs/960w/maple%20leaf-fall_WUTL5UK6KU.jpg
  https://stocksnap.io/license


  Leeroy
  https://cdn.stocksnap.io/img-thumbs/960w/lake-water_RGFJ3WZQI1.jpg
  https://stocksnap.io/license

  Leeroy
  https://cdn.stocksnap.io/img-thumbs/960w/rooftop-satellite%20dish_9O135EFRB2.jpg
  https://stocksnap.io/license



  B S K
  https://images.freeimages.com/images/large-previews/bed/global-team-1238048.jpg
  https://www.freeimages.com/license

  Brad Starkey
  https://unsplash.com/photos/EzZ2hvi8fYg

  Gelatin
  https://www.pexels.com/photo/woman-summer-cute-freedom-6357184/

  Dimitri Weber
  https://www.pexels.com/photo/light-people-water-dark-6199962/




Julie Aagaard
https://images.pexels.com/photos/2587319/pexels-photo-2587319.jpeg?auto=compress&cs=tinysrgb&dpr=3&h=750&w=1260



### code

  Custom 404 page
  https://www.hacksparrow.com/webdev/express/custom-error-pages-404-and-500.html

  Fluid Card Grid code taken from Bryan Robinson
  https://codepen.io/brob/pen/MvwbMa?editors=1100

  CSS Button Tutorial: How to Code Buttons in 5 Simple Steps from Joshua Johnson
  https://designshack.net/articles/css/css-button-tutorial-how-to-code-buttons-in-5-simple-steps/

  HTML <figcaption> Tag from w3schools.com
  https://www.w3schools.com/TAGS/tag_figcaption.asp

  MDN doc on fig caption


  stack overflow article on creating proper image sourcing
  https://stackoverflow.com/questions/49181790/getting-the-src-from-images-set-true-foreach-loop-with-the-src-from-the-model-as

  So much code taken from Tony....sooooo much.