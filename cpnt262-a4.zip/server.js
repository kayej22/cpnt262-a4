const path = require('path');
const dotenv = require('dotenv').config();
const express = require('express');
const cors = require('cors');
const Arrays = require('./data/Arrays');
const mongoose = require('./_connection.js')
// const time = require('./time') 


const app = express();
const array = require('./models/array.js')

// Cors App should this go above view engine?
app.use(cors());

// EJS view engine
app.set('view engine', 'ejs')

app.use((req, res, next) => {
  res.locals = {
    siteTitle: 'Kaye Creative',
    tagline: 'Creative solutions',
    copyright: 'Joel Kaye. MIT License'
  }
  next()
})

// joins pages? research answer
app.use(express.static(path.join(__dirname,'public')))

// app.use(function(req, res, next){ <- using this code also breaks site
//   response.locals = {time: time()};
//   console.log(response.locals.time);
//   next();
// });


// JSON -> application/json-index
app.get('/', (req, res) => {
  res.render('pages/index');
})
// JSON -> application/json-login    
app.get('/login', (req, res) => {
  res.render('pages/login');
})
// JSON -> application/json-register
app.get('/register', (req, res) => {
  res.render('pages/register');
})

// JSON -> application/json 
app.get('/api/v0/Arrays', (req, res) => {
// causing error->  array.find((err, Arrays) => {
// if (err) {
//   res.sendStatus(404)
// }
  res.json(Arrays);
})
// })

// get

// 404 
app.use(function(req, res) {
  res.status(404);
});

// port
const PORT = process.env.PORT || 3000
app.listen(PORT, ()=> {
  console.log(`Listening on port ${PORT}.`)
})


